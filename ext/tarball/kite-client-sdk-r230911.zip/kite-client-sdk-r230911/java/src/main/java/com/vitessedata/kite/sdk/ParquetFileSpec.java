package com.vitessedata.kite.sdk;

public class ParquetFileSpec extends FileSpec {

    public ParquetFileSpec() {
        super("parquet");
    }
}
